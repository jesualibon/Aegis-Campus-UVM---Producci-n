/**
 * Aegis Campus - SafeZone
 * Controlador de Aplicación Web Táctica
 */

// Instancia global del mapa Leaflet
let instanciaMapaLeaflet = null;

// Helpers de Toast y Notificaciones accesibles
const Toast = {
    container: null,
    init() {
        this.container = document.getElementById('toast-container');
    },
    show(message, type = 'info', duration = 3500) {
        if (!this.container) this.init();
        if (!this.container) return;

        const toast = document.createElement('div');
        const types = {
            success: {
                bg: 'bg-[#137333]',
                icon: 'check_circle',
                text: 'text-white'
            },
            error: {
                bg: 'bg-[#c5221f]',
                icon: 'error',
                text: 'text-white'
            },
            warning: {
                bg: 'bg-[#e37400]',
                icon: 'warning',
                text: 'text-white'
            },
            info: {
                bg: 'bg-[#1a73e8]',
                icon: 'info',
                text: 'text-white'
            }
        };

        const config = types[type] || types.info;

        toast.className = `${config.bg} ${config.text} px-4 py-3 rounded-xl shadow-lg flex items-center justify-between gap-3 text-sm transform transition-all duration-300 translate-y-3 opacity-0`;
        toast.innerHTML = `
            <div class="flex items-center gap-2 font-medium">
                <span class="material-symbols-outlined text-[18px]">${config.icon}</span>
                <span>${message}</span>
            </div>
            <button class="hover:opacity-75 transition-opacity" aria-label="Cerrar">
                <span class="material-symbols-outlined text-[16px]">close</span>
            </button>
        `;

        const closeBtn = toast.querySelector('button');
        const removeToast = () => {
            toast.classList.add('opacity-0', 'translate-y-2');
            setTimeout(() => {
                if (toast.parentElement) toast.remove();
            }, 300);
        };

        closeBtn.addEventListener('click', removeToast);
        this.container.appendChild(toast);

        // Entrada fluida
        requestAnimationFrame(() => {
            toast.classList.remove('opacity-0', 'translate-y-3');
        });

        setTimeout(removeToast, duration);
    }
};

// Catálogo de Zonas del Campus y coordenadas estimadas sobre el mapa ortogonal (Orientación Horizontal 791x489)
// Puntos calibrados al centroide geométrico exacto de cada edificio y área
const ZONAS_CAMPUS = {
    // Edificios Académicos (Centrados con precisión milimétrica en sus techos)
    "Edificio E - Fisioterapia (PB)": { url: '/img/fisioterapia.jpg', lat: 21.0470, lng: -89.6328, top: '36.5%', left: '19.8%' }, // Sector E (Planta Baja)
    "Edificio E - Centro de Cómputo (PA)": { url: null, lat: 21.0470, lng: -89.6328, top: '36.5%', left: '19.8%' }, // Mismo edificio E (Planta Alta)
    "Edificio D - Lab. Gastronomía": { url: '/img/gastronomia.jpg', lat: 21.0465, lng: -89.6330, top: '37.2%', left: '7.0%' }, // Sector D (Centroide de techo)
    "Edificio B - Biblioteca / CAE": { url: null, lat: 21.0465, lng: -89.6325, top: '58.0%', left: '6.2%' }, // Sector B (Centroide de techo)
    "Edificio I - Taller de Diseño": { url: '/img/diseno.jpg', lat: 21.0472, lng: -89.6330, top: '34.8%', left: '28.4%' }, // Sector I (Centroide de techo)
    "Edificio H - Aulas y Cubículos": { url: null, lat: 21.0480, lng: -89.6322, top: '50.1%', left: '49.9%' }, // Sector H (Techo gris frente al campo)

    // Zonas Deportivas (Centrados en el núcleo funcional de cada complejo)
    "Zona 1 - Alberca (PB)": { url: '/img/alberca.jpg', lat: 21.0485, lng: -89.6315, top: '77.5%', left: '52.3%' }, // Sector 1 (Planta Baja - Área de alberca)
    "Zona 1 - Gimnasio (PA)": { url: '/img/alberca.jpg', lat: 21.0485, lng: -89.6315, top: '77.5%', left: '52.3%' }, // Sector 1 (Planta Alta - Gimnasio)
    "Zona 2 - Campo Deportivo": { url: null, lat: 21.0490, lng: -89.6325, top: '55.2%', left: '68.9%' }, // Sector 2 (Círculo central de la cancha de fútbol)
    "Zona 3 - Cancha de Usos Múltiples": { url: null, lat: 21.0482, lng: -89.6320, top: '68.5%', left: '52.5%' }, // Cancha exterior de usos múltiples

    // Estacionamientos (Centrados en los cuadrantes de cada figura)
    "Estacionamiento Norte (Círculo - Campo)": { url: null, lat: 21.0495, lng: -89.6335, top: '13.3%', left: '71.6%' }, // Círculo norte
    "Estacionamiento Central (Triángulo - Edificios)": { url: null, lat: 21.0475, lng: -89.6320, top: '44.0%', left: '38.0%' }, // Triángulo central
    "Estacionamiento Sur-Oeste (Cuadrado - Diseño)": { url: null, lat: 21.0472, lng: -89.6332, top: '29.7%', left: '40.0%' } // Cuadrado sur-oeste
};

// Normalización de texto (elimina acentos, diacríticos y espacios extra)
function normalizarTexto(texto) {
    if (!texto) return '';
    return texto
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '') // Quita acentos y tildes
        .trim();
}

// Búsqueda flexible de zona en el catálogo ZONAS_CAMPUS
function obtenerInfoZona(zona_id) {
    if (!zona_id) return null;
    if (ZONAS_CAMPUS[zona_id]) {
        return { nombre: zona_id, ...ZONAS_CAMPUS[zona_id] };
    }

    const zNorm = normalizarTexto(zona_id);
    for (const [nombre, info] of Object.entries(ZONAS_CAMPUS)) {
        const nomNorm = normalizarTexto(nombre);
        if (nomNorm === zNorm || nomNorm.includes(zNorm) || zNorm.includes(nomNorm)) {
            return { nombre, ...info };
        }
    }

    // Coincidencias por palabras clave
    if (zNorm.includes('fisio')) return { nombre: "Edificio E - Fisioterapia (PB)", ...ZONAS_CAMPUS["Edificio E - Fisioterapia (PB)"] };
    if (zNorm.includes('computo')) return { nombre: "Edificio E - Centro de Cómputo (PA)", ...ZONAS_CAMPUS["Edificio E - Centro de Cómputo (PA)"] };
    if (zNorm.includes('gastronom') || zNorm.includes('cocina')) return { nombre: "Edificio D - Lab. Gastronomía", ...ZONAS_CAMPUS["Edificio D - Lab. Gastronomía"] };
    if (zNorm.includes('biblioteca') || zNorm.includes('cae')) return { nombre: "Edificio B - Biblioteca / CAE", ...ZONAS_CAMPUS["Edificio B - Biblioteca / CAE"] };
    if (zNorm.includes('disen') || zNorm.includes('taller')) return { nombre: "Edificio I - Taller de Diseño", ...ZONAS_CAMPUS["Edificio I - Taller de Diseño"] };
    if (zNorm.includes('edificio h') || zNorm.includes('cubiculo') || zNorm.includes('sector h')) return { nombre: "Edificio H - Aulas y Cubículos", ...ZONAS_CAMPUS["Edificio H - Aulas y Cubículos"] };
    if (zNorm.includes('alberca')) return { nombre: "Zona 1 - Alberca (PB)", ...ZONAS_CAMPUS["Zona 1 - Alberca (PB)"] };
    if (zNorm.includes('gimnasio') || zNorm.includes('gym')) return { nombre: "Zona 1 - Gimnasio (PA)", ...ZONAS_CAMPUS["Zona 1 - Gimnasio (PA)"] };
    if (zNorm.includes('campo')) return { nombre: "Zona 2 - Campo Deportivo", ...ZONAS_CAMPUS["Zona 2 - Campo Deportivo"] };
    if (zNorm.includes('cancha') || zNorm.includes('usos multiples')) return { nombre: "Zona 3 - Cancha de Usos Múltiples", ...ZONAS_CAMPUS["Zona 3 - Cancha de Usos Múltiples"] };
    if (zNorm.includes('estacionamiento norte') || zNorm.includes('circulo')) return { nombre: "Estacionamiento Norte (Círculo - Campo)", ...ZONAS_CAMPUS["Estacionamiento Norte (Círculo - Campo)"] };
    if (zNorm.includes('estacionamiento central') || zNorm.includes('triangulo')) return { nombre: "Estacionamiento Central (Triángulo - Edificios)", ...ZONAS_CAMPUS["Estacionamiento Central (Triángulo - Edificios)"] };
    if (zNorm.includes('estacionamiento sur') || zNorm.includes('cuadrado')) return { nombre: "Estacionamiento Sur-Oeste (Cuadrado - Diseño)", ...ZONAS_CAMPUS["Estacionamiento Sur-Oeste (Cuadrado - Diseño)"] };

    return null;
}

// Búsqueda de fotografía de referencia si existe
function obtenerImagenZona(zona_id) {
    const info = obtenerInfoZona(zona_id);
    if (info && info.url) {
        return { url: info.url, nombre: info.nombre };
    }
    return null;
}

// Coordenadas oficiales UVM Campus Mérida
const CAMPUS_CONFIG = {
    center: [21.0475, -89.6322],
    // Perímetro estricto de la universidad
    bounds: {
        minLat: 21.0455,
        maxLat: 21.0495,
        minLng: -89.6345,
        maxLng: -89.6300
    }
};

// Función para obtener coordenadas garantizadas dentro del campus
function generarUbicacionCampusFallback() {
    const { bounds, center } = CAMPUS_CONFIG;
    // Dispersión sutil controlada en el campus
    const lat = bounds.minLat + Math.random() * (bounds.maxLat - bounds.minLat);
    const lng = bounds.minLng + Math.random() * (bounds.maxLng - bounds.minLng);
    return { lat: Number(lat.toFixed(6)), lng: Number(lng.toFixed(6)) };
}

document.addEventListener('DOMContentLoaded', () => {
    Toast.init();

    // 1. Inicialización de WebSocket y monitoreo de estado
    const socket = io();
    const wsStatus = document.getElementById('ws-status');
    const wsDot = document.getElementById('ws-indicator-dot');
    const wsText = document.getElementById('ws-status-text');

    function actualizarEstadoWS(conectado) {
        if (!wsStatus) return;
        if (conectado) {
            wsStatus.className = 'flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#e6f4ea] text-[#137333] transition-all';
            wsDot.className = 'w-2 h-2 rounded-full bg-[#188038]';
            wsText.textContent = 'En Línea';
        } else {
            wsStatus.className = 'flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#fce8e6] text-[#c5221f] transition-all';
            wsDot.className = 'w-2 h-2 rounded-full bg-[#d93025] animate-pulse';
            wsText.textContent = 'Desconectado';
        }
    }

    socket.on('connect', () => {
        actualizarEstadoWS(true);
        Toast.show('Conectado al Centro de Operaciones en Tiempo Real', 'info', 2500);
    });

    socket.on('disconnect', () => {
        actualizarEstadoWS(false);
        Toast.show('Conexión perdida con el servidor. Reconectando...', 'warning', 4000);
    });

    // 2. Modal de Fotografías y Planos de Zona (si existe en el DOM)
    const modalFoto = document.getElementById('modal-foto');
    const modalImg = document.getElementById('modal-img');
    const modalTitulo = document.getElementById('modal-titulo');
    const btnCerrarModal = document.getElementById('btn-cerrar-modal');

    function abrirModal(rutaImg, tituloZona) {
        if (!modalFoto || !modalImg) return;
        modalImg.src = rutaImg;
        if (modalTitulo) {
            modalTitulo.innerHTML = `
                <span class="material-symbols-outlined text-[#1a73e8]">photo_camera</span>
                <span>Distribución Física: <strong>${tituloZona}</strong></span>
            `;
        }
        modalFoto.classList.remove('hidden');
        modalFoto.classList.add('flex');
    }

    function cerrarModal() {
        if (!modalFoto) return;
        modalFoto.classList.add('hidden');
        modalFoto.classList.remove('flex');
    }

    if (btnCerrarModal) btnCerrarModal.addEventListener('click', cerrarModal);
    if (modalFoto) {
        modalFoto.addEventListener('click', (e) => {
            if (e.target === modalFoto) cerrarModal();
        });
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modalFoto && !modalFoto.classList.contains('hidden')) {
            cerrarModal();
        }
    });

    // 3. Envío y Procesamiento del Formulario de Emergencia (solo si existe en el DOM)
    const form = document.getElementById('form-emergencia');
    const statusMsg = document.getElementById('status-msg');
    const btnSubmit = document.getElementById('btn-submit');

    function mostrarEstadoForm(texto, colorClass) {
        if (!statusMsg) return;
        statusMsg.textContent = texto;
        statusMsg.className = `text-xs mt-3 font-medium text-center ${colorClass}`;
        statusMsg.classList.remove('hidden');
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const tipoEmergencia = document.getElementById('tipo_emergencia').value;
            const zonaId = document.getElementById('zona_id').value;

            if (!tipoEmergencia || !zonaId) {
                Toast.show('Por favor completa todos los campos requeridos (*)', 'warning');
                return;
            }

            mostrarEstadoForm('Verificando telemetría de geolocalización...', 'text-[#1a73e8]');
            if (btnSubmit) btnSubmit.disabled = true;

            const zonaInfo = obtenerInfoZona(zonaId);

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (pos) => {
                        const coords = {
                            lat: pos.coords.latitude,
                            lng: pos.coords.longitude
                        };
                        // Si el GPS físico está a más de 20 km de Mérida (ej. pruebas en otra ciudad), usar la zona o fallback del campus
                        if (coords.lat < 20.8 || coords.lat > 21.2 || coords.lng < -90.0 || coords.lng > -89.3) {
                            const targetLat = (zonaInfo && zonaInfo.lat) ? zonaInfo.lat : generarUbicacionCampusFallback().lat;
                            const targetLng = (zonaInfo && zonaInfo.lng) ? zonaInfo.lng : generarUbicacionCampusFallback().lng;
                            enviarReporte(targetLat, targetLng);
                        } else {
                            enviarReporte(coords.lat, coords.lng);
                        }
                    },
                    (err) => {
                        console.info("[Geo] GPS no disponible o denegado, asignando ubicación por zona en catálogo.");
                        const targetLat = (zonaInfo && zonaInfo.lat) ? zonaInfo.lat : generarUbicacionCampusFallback().lat;
                        const targetLng = (zonaInfo && zonaInfo.lng) ? zonaInfo.lng : generarUbicacionCampusFallback().lng;
                        enviarReporte(targetLat, targetLng);
                    },
                    { timeout: 4000 }
                );
            } else {
                const targetLat = (zonaInfo && zonaInfo.lat) ? zonaInfo.lat : generarUbicacionCampusFallback().lat;
                const targetLng = (zonaInfo && zonaInfo.lng) ? zonaInfo.lng : generarUbicacionCampusFallback().lng;
                enviarReporte(targetLat, targetLng);
            }
        });

        async function enviarReporte(lat, lng) {
            const inputNombre = document.getElementById('nombre_reportante');
            const inputTelefono = document.getElementById('telefono');

            const payload = {
                nombre_reportante: inputNombre ? inputNombre.value.trim() : '',
                telefono: inputTelefono ? inputTelefono.value.trim() : '',
                tipo_emergencia: document.getElementById('tipo_emergencia').value,
                severidad: document.getElementById('severidad').value,
                zona_id: document.getElementById('zona_id').value,
                descripcion: document.getElementById('descripcion').value.trim(),
                coordenadas: { lat, lng }
            };

            try {
                mostrarEstadoForm('Transmitiendo alerta REST al servidor...', 'text-[#1a73e8]');
                const response = await fetch('/api/v1/incidentes', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.error || 'Error al transmitir reporte');
                }

                mostrarEstadoForm('¡Alerta transmitida con éxito!', 'text-[#137333]');
                Toast.show('Incidente registrado y vinculado al expediente médico', 'success');

                const tarjetaConfirmacion = document.getElementById('confirmacion-alerta');
                if (tarjetaConfirmacion && data.incidente) {
                    const confId = document.getElementById('conf-id');
                    const confZona = document.getElementById('conf-zona');
                    const confTipo = document.getElementById('conf-tipo-prioridad');
                    const confTel = document.getElementById('conf-telefono');
                    const confSoap = document.getElementById('conf-soap-titular');

                    if (confId) confId.textContent = data.incidente.id;
                    if (confZona) confZona.textContent = data.incidente.zona_id;
                    if (confTipo) confTipo.textContent = `${data.incidente.tipo_emergencia} (${data.incidente.severidad})`;
                    if (confTel) confTel.textContent = (data.incidente.telefono && data.incidente.telefono !== 'No proporcionado') ? data.incidente.telefono : 'Anónimo';
                    if (confSoap && data.incidente.expediente_soap) {
                        confSoap.textContent = data.incidente.expediente_soap.afiliacion || data.incidente.expediente_soap.titular || 'Visitante / Comunidad UVM';
                    }

                    form.classList.add('hidden');
                    tarjetaConfirmacion.classList.remove('hidden');
                    tarjetaConfirmacion.classList.add('flex');
                } else {
                    form.reset();
                    setTimeout(() => {
                        if (statusMsg) statusMsg.classList.add('hidden');
                    }, 3000);
                }
            } catch (error) {
                mostrarEstadoForm(error.message, 'text-[#c5221f]');
                Toast.show(error.message, 'error');
            } finally {
                if (btnSubmit) btnSubmit.disabled = false;
            }
        }

        // Botón para emitir nuevo reporte tras la confirmación
        const btnNuevoReporte = document.getElementById('btn-nuevo-reporte');
        if (btnNuevoReporte) {
            btnNuevoReporte.addEventListener('click', () => {
                const tarjetaConfirmacion = document.getElementById('confirmacion-alerta');
                if (tarjetaConfirmacion) {
                    tarjetaConfirmacion.classList.add('hidden');
                    tarjetaConfirmacion.classList.remove('flex');
                }
                form.reset();
                form.classList.remove('hidden');
                if (statusMsg) {
                    statusMsg.classList.add('hidden');
                }
            });
        }
    }

    // =========================================================================
    // 4. MÓDULO DEL CENTRO DE MANDO TÁCTICO (DASHBOARD.HTML)
    // Validación estricta: Solo inicializa Leaflet (L.map('mapa')), los botones de
    // vista 2D/3D y la escucha de eventos Socket.io si #mapa existe en el DOM actual
    // =========================================================================
    const contenedorMapa = document.getElementById('mapa');
    if (contenedorMapa) {
        
        // 4.1. Inicialización de Leaflet (L.map('mapa'))
        if (typeof L !== 'undefined') {
            instanciaMapaLeaflet = L.map('mapa', {
                center: CAMPUS_CONFIG.center,
                zoom: 17,
                minZoom: 15,
                maxZoom: 19
            });

            L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
                attribution: 'Tiles &copy; Esri, UVM Mérida',
                maxZoom: 19
            }).addTo(instanciaMapaLeaflet);
        }

        let marcadores = {};

        // 4.2. Botones de vista 2D/3D y conmutador de mapas
        const btn2d = document.getElementById('btn-vista-2d');
        const btn3d = document.getElementById('btn-vista-3d');
        const mapa2dContainer = document.getElementById('mapa');
        const render3dContainer = document.getElementById('render-3d-container');
        const pinsOrtogonalLayer = document.getElementById('pins-ortogonal-layer');
        let pinsOrtogonales = {};

        function renderizarPinOrtogonal(incidente) {
            if (!pinsOrtogonalLayer) return;
            const info = obtenerInfoZona(incidente.zona_id);
            if (!info || !info.top || !info.left) return;

            const pinExistente = document.getElementById(`pin-orto-${incidente.id}`);
            if (pinExistente) pinExistente.remove();

            const baseTop = parseFloat(info.top);
            const baseLeft = parseFloat(info.left);

            const pinesMismaZona = Object.values(pinsOrtogonales).filter(p => {
                const pZona = p.getAttribute('data-zona-base');
                return pZona === info.nombre || (Math.abs(parseFloat(p.getAttribute('data-base-left')) - baseLeft) < 1.0 && Math.abs(parseFloat(p.getAttribute('data-base-top')) - baseTop) < 1.0);
            });

            const orden = pinesMismaZona.length;
            let offsetLeft = 0;
            let offsetTop = 0;

            if (orden > 0) {
                const radioX = 2.4;
                const radioY = 3.6;
                const angulo = (orden * 2.39996) + (Math.PI / 4);
                offsetLeft = Math.cos(angulo) * radioX;
                offsetTop = Math.sin(angulo) * radioY;
            }

            const finalTop = `${(baseTop + offsetTop).toFixed(2)}%`;
            const finalLeft = `${(baseLeft + offsetLeft).toFixed(2)}%`;

            const pin = document.createElement('div');
            pin.id = `pin-orto-${incidente.id}`;
            pin.setAttribute('data-zona-base', info.nombre);
            pin.setAttribute('data-base-top', baseTop);
            pin.setAttribute('data-base-left', baseLeft);
            pin.className = "absolute pointer-events-auto transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer z-20 transition-all duration-300";
            pin.style.top = finalTop;
            pin.style.left = finalLeft;

            let pinBg = "bg-[#1a73e8]";
            if (incidente.severidad === 'ALTA') pinBg = "bg-[#d93025]";
            else if (incidente.severidad === 'MEDIA') pinBg = "bg-[#f9ab00]";

            pin.innerHTML = `
                <div class="relative flex items-center justify-center">
                    <span class="animate-ping absolute inline-flex h-6 w-6 rounded-full opacity-75 ${pinBg}"></span>
                    <div class="w-5 h-5 ${pinBg} rounded-full border-2 border-white shadow-lg flex items-center justify-center text-white">
                        <span class="w-1.5 h-1.5 bg-white rounded-full"></span>
                    </div>
                </div>
                <div class="opacity-0 group-hover:opacity-100 transition-opacity bg-black/90 text-white text-[11px] font-medium px-2.5 py-1.5 rounded-lg absolute bottom-full left-1/2 -translate-x-1/2 mb-2 whitespace-nowrap shadow-xl pointer-events-none z-40 border border-white/20 backdrop-blur-sm">
                    <span class="font-bold text-amber-300">${incidente.id}</span>: ${info.nombre}
                    <div class="text-[10px] text-slate-300 font-normal">Prioridad: ${incidente.severidad}</div>
                </div>
            `;

            if (info.url) {
                pin.addEventListener('click', () => {
                    abrirModal(info.url, info.nombre);
                });
            }

            pinsOrtogonalLayer.appendChild(pin);
            pinsOrtogonales[incidente.id] = pin;
        }

        function alternarVista(modo) {
            if (modo === '3d') {
                mapa2dContainer.classList.add('hidden');
                render3dContainer.classList.remove('hidden');
                btn3d.className = "px-3 py-1 text-xs font-medium rounded-full bg-white text-[#1a73e8] shadow-sm transition-all flex items-center gap-1";
                btn2d.className = "px-3 py-1 text-xs font-medium rounded-full text-[#5f6368] hover:text-[#202124] transition-all flex items-center gap-1";
                Toast.show('Mapa Satelital Ortogonal UVM Mérida activado', 'info', 2000);
            } else {
                render3dContainer.classList.add('hidden');
                mapa2dContainer.classList.remove('hidden');
                btn2d.className = "px-3 py-1 text-xs font-medium rounded-full bg-white text-[#1a73e8] shadow-sm transition-all flex items-center gap-1";
                btn3d.className = "px-3 py-1 text-xs font-medium rounded-full text-[#5f6368] hover:text-[#202124] transition-all flex items-center gap-1";
                
                if (instanciaMapaLeaflet) {
                    setTimeout(() => {
                        instanciaMapaLeaflet.invalidateSize();
                    }, 100);
                }
            }
        }

        if (btn2d) btn2d.addEventListener('click', () => alternarVista('2d'));
        if (btn3d) btn3d.addEventListener('click', () => alternarVista('3d'));

        // 4.3. Renderizado y gestión de la bitácora de incidentes
        const listaIncidentes = document.getElementById('lista-incidentes');
        const emptyState = document.getElementById('empty-state');
        const contadorIncidentes = document.getElementById('contador-incidentes');

        function actualizarContador() {
            const total = Object.keys(marcadores).length;
            if (contadorIncidentes) {
                contadorIncidentes.textContent = `${total} ${total === 1 ? 'activo' : 'activos'}`;
            }
        }

        function renderizarIncidente(incidente, esNuevo = false) {
            if (emptyState) emptyState.style.display = 'none';

            if (document.getElementById(`card-${incidente.id}`)) {
                return;
            }

            let badgeColor = 'bg-[#e8f0fe] text-[#1a73e8]';
            let iconName = 'info';
            let iconColor = 'text-[#1a73e8]';

            if (incidente.severidad === 'ALTA') {
                badgeColor = 'bg-[#fce8e6] text-[#c5221f]';
                iconName = 'warning';
                iconColor = 'text-[#c5221f]';
            } else if (incidente.severidad === 'MEDIA') {
                badgeColor = 'bg-[#fef7e0] text-[#b06000]';
                iconName = 'priority_high';
                iconColor = 'text-[#e37400]';
            }

            const infoFoto = obtenerImagenZona(incidente.zona_id);
            const soapData = incidente.expediente_soap || {
                tipo_sangre: 'No registrado',
                alergias: 'Ninguna conocida',
                poliza: 'N/A',
                contacto: 'N/A'
            };

            const telefonoMostrar = (incidente.telefono && incidente.telefono !== 'No proporcionado') ? incidente.telefono : 'Anónimo';

            const card = document.createElement('div');
            card.className = `border border-[#dadce0] rounded-xl p-5 bg-white flex flex-col md:flex-row gap-4 items-start ${esNuevo ? 'incidente-nuevo shadow-md' : 'shadow-sm'} transition-all`;
            card.id = `card-${incidente.id}`;

            card.innerHTML = `
                <div class="p-3 rounded-full bg-[#f8f9fa] border border-[#dadce0] shrink-0">
                    <span class="material-symbols-outlined ${iconColor}">${iconName}</span>
                </div>
                <div class="flex-grow w-full">
                    <div class="flex justify-between items-center mb-1 flex-wrap gap-2">
                        <div class="flex items-center gap-2">
                            <span class="font-medium text-[#202124] text-sm">${incidente.id}</span>
                            <span class="text-xs font-medium px-2.5 py-0.5 rounded-full ${badgeColor}">${incidente.tipo_emergencia}</span>
                            <span class="text-xs font-semibold text-[#5f6368]">${incidente.severidad}</span>
                        </div>
                        <span class="text-xs text-[#5f6368]">${new Date(incidente.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                    </div>

                    <p class="text-sm text-[#202124] mb-1">
                        <span class="text-[#5f6368]">Zona:</span> <strong>${incidente.zona_id}</strong> &nbsp;•&nbsp; 
                        <span class="text-[#5f6368]">Teléfono:</span> <span class="font-medium text-xs bg-[#f1f3f4] px-1.5 py-0.5 rounded text-[#202124]">${telefonoMostrar}</span>
                        ${incidente.nombre_reportante && incidente.nombre_reportante !== 'Anónimo' ? `&nbsp;•&nbsp; <span class="text-[#5f6368]">Reportante:</span> <span class="text-xs text-[#5f6368] font-medium">${incidente.nombre_reportante}</span>` : ''}
                    </p>

                    <p class="text-xs text-[#5f6368] mb-3 leading-relaxed">${incidente.descripcion || 'Sin descripción adicional.'}</p>
                    
                    ${infoFoto ? `
                        <div class="zona-preview-btn mb-3 rounded-lg overflow-hidden border border-[#dadce0] bg-slate-100 relative group cursor-pointer" data-img="${infoFoto.url}" data-nombre="${infoFoto.nombre}">
                            <img src="${infoFoto.url}" alt="${infoFoto.nombre}" class="w-full h-36 object-cover group-hover:scale-105 transition-transform duration-300">
                            <div class="absolute bottom-2 right-2 bg-black/70 text-white text-[11px] px-2.5 py-1 rounded-full flex items-center gap-1 backdrop-blur-sm">
                                <span class="material-symbols-outlined text-[14px]">zoom_in</span>
                                Ver distribución física: ${infoFoto.nombre}
                            </div>
                        </div>
                    ` : ''}

                    <!-- Ficha Médica SOAP Simulada -->
                    <div class="bg-[#f8f9fa] rounded-lg p-3 border border-[#dadce0] text-xs">
                        <div class="flex items-center justify-between flex-wrap gap-1 text-[#137333] font-medium mb-1">
                            <div class="flex items-center gap-1.5">
                                <span class="material-symbols-outlined text-[16px]">verified_user</span>
                                <span>Expediente Clínico Vinculado (Protocolo SOAP)</span>
                            </div>
                            <span class="text-[11px] font-normal text-[#5f6368]">${soapData.afiliacion || soapData.titular || 'Visitante / Comunidad UVM'}</span>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-[#5f6368] mt-1.5 pt-1.5 border-t border-[#e8eaed]">
                            <div><span class="font-medium text-[#202124]">Tipo de Sangre:</span> <span class="text-[#1a73e8] font-bold">${soapData.tipo_sangre}</span></div>
                            <div><span class="font-medium text-[#202124]">Alergias Críticas:</span> <span class="text-[#c5221f] font-medium">${soapData.alergias}</span></div>
                            <div><span class="font-medium text-[#202124]">Póliza Activa:</span> ${soapData.poliza || 'N/A'}</div>
                            <div><span class="font-medium text-[#202124]">Contacto SOS:</span> ${soapData.contacto || 'N/A'}</div>
                        </div>
                    </div>
                </div>
            `;

            const previewBtn = card.querySelector('.zona-preview-btn');
            if (previewBtn) {
                previewBtn.addEventListener('click', () => {
                    abrirModal(previewBtn.getAttribute('data-img'), previewBtn.getAttribute('data-nombre'));
                });
            }

            if (listaIncidentes) {
                listaIncidentes.prepend(card);
            }

            if (incidente.coordenadas && incidente.coordenadas.lat && instanciaMapaLeaflet) {
                const markerColor = incidente.severidad === 'ALTA' ? '#d93025' : (incidente.severidad === 'MEDIA' ? '#f9ab00' : '#1a73e8');
                const circleMarker = L.circleMarker([incidente.coordenadas.lat, incidente.coordenadas.lng], {
                    radius: 8,
                    fillColor: markerColor,
                    color: '#ffffff',
                    weight: 2,
                    opacity: 1,
                    fillOpacity: 0.95
                }).addTo(instanciaMapaLeaflet).bindPopup(`
                    <div style="font-family: Roboto, sans-serif; text-align: left; padding: 2px;">
                        <div style="font-weight: 700; color: #202124;">${incidente.id} (${incidente.tipo_emergencia})</div>
                        <div style="color: #5f6368; font-size: 12px; margin-top: 2px;">${incidente.zona_id}</div>
                        <div style="color: #1a73e8; font-size: 11px; margin-top: 4px;">Prioridad: ${incidente.severidad}</div>
                    </div>
                `);

                marcadores[incidente.id] = circleMarker;
                if (esNuevo) {
                    instanciaMapaLeaflet.setView([incidente.coordenadas.lat, incidente.coordenadas.lng], 18);
                    circleMarker.openPopup();
                }
            }

            renderizarPinOrtogonal(incidente);
            actualizarContador();
        }

        // 4.4. Carga inicial de incidentes activos
        fetch('/api/v1/incidentes/activos')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data) && data.length > 0) {
                    data.slice().reverse().forEach(incidente => renderizarIncidente(incidente, false));
                }
                actualizarContador();
            })
            .catch(err => {
                console.error('Error al sincronizar incidentes iniciales:', err);
                Toast.show('No se pudieron obtener incidentes previos', 'warning');
            });

        // 4.5. Escucha de eventos Socket.io en tiempo real
        socket.on('nueva_alerta', (nuevoIncidente) => {
            renderizarIncidente(nuevoIncidente, true);
            Toast.show(`Nueva Alerta recibida: ${nuevoIncidente.id} - ${nuevoIncidente.zona_id}`, 'error', 4000);
        });

        socket.on('limpiar_mapa', () => {
            if (listaIncidentes) {
                listaIncidentes.innerHTML = `
                    <div class="flex flex-col items-center justify-center text-center py-16" id="empty-state">
                        <span class="material-symbols-outlined text-5xl text-[#dadce0] mb-3">check_circle</span>
                        <p class="text-[#5f6368] font-medium text-sm">Sin incidentes activos</p>
                        <p class="text-[#80868b] text-xs mt-1">Las alertas emitidas vía REST se sincronizarán aquí inmediatamente por WebSocket.</p>
                    </div>`;
            }

            Object.values(marcadores).forEach(marker => {
                if (instanciaMapaLeaflet) instanciaMapaLeaflet.removeLayer(marker);
            });
            marcadores = {};

            if (pinsOrtogonalLayer) {
                pinsOrtogonalLayer.innerHTML = '';
            }
            pinsOrtogonales = {};
            actualizarContador();
            Toast.show('Tablero táctico reiniciado', 'info');
        });

        // 4.6. Botón Limpiar Tablero
        const btnReset = document.getElementById('btn-reset');
        if (btnReset) {
            btnReset.addEventListener('click', async () => {
                try {
                    const res = await fetch('/api/v1/expo/reset', { method: 'POST' });
                    const data = await res.json();
                    console.log(data.mensaje);
                } catch (err) {
                    Toast.show('Error al solicitar reinicio de tablero', 'error');
                }
            });
        }
    }
});