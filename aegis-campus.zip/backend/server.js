const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Medidas de Seguridad con Helmet y CSP estricto y compatible
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: [
                "'self'",
                "https://cdn.tailwindcss.com",
                "https://unpkg.com"
            ],
            styleSrc: [
                "'self'",
                "'unsafe-inline'",
                "https://unpkg.com",
                "https://fonts.googleapis.com"
            ],
            fontSrc: [
                "'self'",
                "https://fonts.gstatic.com",
                "data:"
            ],
            imgSrc: [
                "'self'",
                "data:",
                "blob:",
                "https://server.arcgisonline.com",
                "https://*.arcgisonline.com",
                "https://unpkg.com"
            ],
            connectSrc: [
                "'self'",
                "ws:",
                "wss:",
                "http:",
                "https:"
            ]
        }
    },
    crossOriginEmbedderPolicy: false
}));

app.use(cors());
app.use(express.json({ limit: '10kb' })); // Limita tamaño del payload para evitar sobrecarga
app.use(express.text({ type: ['text/xml', 'application/xml', 'text/plain'], limit: '50kb' })); // Soporte XML para SOAP

// Rutas de Vistas Web
// 1. Ruta raíz: Vista móvil pública para reportar emergencias
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/reportar.html'));
});

// 2. Ruta Centro de Mando: Vista del monitor táctico en tiempo real
app.get('/centro-mando', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/dashboard.html'));
});

// Servicio de archivos estáticos (JS, CSS, imágenes) deshabilitando index automático para priorizar las rutas
app.use(express.static(path.join(__dirname, '../frontend'), { index: false }));

// Rate Limiter para reportes de emergencia
const reportLimiter = rateLimit({
    windowMs: 3 * 60 * 1000, // 3 minutos
    max: 10, // Ajustado a 10 para demos interactivas fluidas sin permitir flood
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Demasiados reportes enviados desde esta IP. Por favor espere un momento." }
});

// Base de datos simulada en memoria para incidentes
let incidentesActivos = [];

// Catálogo y perfiles médicos simulados SOAP (búsqueda por teléfono de contacto o matrícula)
const expedientesMedicosDemo = {
    // Perfil general para visitantes o comunidad UVM sin expediente previo registrado
    "visitante": {
        titular: "Visitante / Comunidad UVM",
        afiliacion: "Visitante / Comunidad UVM",
        estatus_poliza: "COBERTURA GENERAL RESPONSABILIDAD CIVIL CAMPUS",
        tipo_sangre: "O+",
        alergias: "Ninguna registrada (Verificar en sitio)",
        poliza: "AXA-CAMPUS-99201",
        contacto: "No proporcionado"
    },
    "default": {
        titular: "Visitante / Comunidad UVM",
        afiliacion: "Visitante / Comunidad UVM",
        estatus_poliza: "COBERTURA GENERAL RESPONSABILIDAD CIVIL CAMPUS",
        tipo_sangre: "O+",
        alergias: "Ninguna registrada (Verificar en sitio)",
        poliza: "AXA-CAMPUS-99201",
        contacto: "No proporcionado"
    },
    // Expedientes demo vinculados por teléfono de contacto
    "9995550192": {
        titular: "Sofía Valentina Ramírez Peña",
        matricula: "88019234",
        afiliacion: "Estudiante Licenciatura UVM",
        estatus_poliza: "ACTIVA",
        tipo_sangre: "O Positivo",
        alergias: "Penicilina",
        poliza: "AXA-99201-UVM",
        contacto: "999-555-0192"
    },
    "9993127744": {
        titular: "Emiliano Gómez Navarrete",
        matricula: "88014522",
        afiliacion: "Estudiante Posgrado UVM",
        estatus_poliza: "ACTIVA",
        tipo_sangre: "A Positivo",
        alergias: "Sulfamidas",
        poliza: "GNP-CAMPUS-3382",
        contacto: "999-312-7744"
    },
    "9999401122": {
        titular: "Dra. Mariana Morales Cetina",
        matricula: "88023190",
        afiliacion: "Personal Docente UVM",
        estatus_poliza: "ACTIVA",
        tipo_sangre: "B Positivo",
        alergias: "Ibuprofeno",
        poliza: "METLIFE-CAMPUS-5541",
        contacto: "999-940-1122"
    },
    // Compatibilidad adicional por matrícula
    "88019234": {
        titular: "Sofía Valentina Ramírez Peña",
        matricula: "88019234",
        afiliacion: "Estudiante Licenciatura UVM",
        estatus_poliza: "ACTIVA",
        tipo_sangre: "O Positivo",
        alergias: "Penicilina",
        poliza: "AXA-99201-UVM",
        contacto: "999-555-0192"
    },
    "88014522": {
        titular: "Emiliano Gómez Navarrete",
        matricula: "88014522",
        afiliacion: "Estudiante Posgrado UVM",
        estatus_poliza: "ACTIVA",
        tipo_sangre: "A Positivo",
        alergias: "Sulfamidas",
        poliza: "GNP-CAMPUS-3382",
        contacto: "999-312-7744"
    }
};

// Búsqueda inteligente de expediente SOAP por teléfono de contacto o matrícula sin exigir matrícula
function buscarExpedienteMedico({ telefono, matricula, nombre } = {}) {
    // 1. Coincidencia por teléfono si fue proporcionado
    if (telefono && telefono !== "No proporcionado") {
        const digitos = telefono.replace(/\D/g, '');
        if (digitos) {
            // Coincidencia directa por dígitos o formato
            if (expedientesMedicosDemo[digitos]) {
                return { ...expedientesMedicosDemo[digitos] };
            }
            if (expedientesMedicosDemo[telefono]) {
                return { ...expedientesMedicosDemo[telefono] };
            }
            // Búsqueda iterativa en los números de contacto del catálogo
            for (const clave of Object.keys(expedientesMedicosDemo)) {
                const perfil = expedientesMedicosDemo[clave];
                if (perfil.contacto) {
                    const contactoDigitos = perfil.contacto.replace(/\D/g, '');
                    if (contactoDigitos && (contactoDigitos === digitos || digitos.endsWith(contactoDigitos) || contactoDigitos.endsWith(digitos))) {
                        return { ...perfil };
                    }
                }
            }
        }
    }

    // 2. Coincidencia secundaria por matrícula si se proporciona
    if (matricula && expedientesMedicosDemo[matricula]) {
        return { ...expedientesMedicosDemo[matricula] };
    }

    // 3. Perfil general de "Visitante / Comunidad UVM"
    const perfilBase = expedientesMedicosDemo.visitante || expedientesMedicosDemo.default;
    return {
        ...perfilBase,
        titular: (nombre && nombre !== "Anónimo") ? nombre : "Visitante / Comunidad UVM",
        contacto: (telefono && telefono !== "No proporcionado") ? telefono : "No proporcionado"
    };
}

// Función de sanitización y limpieza de cadenas
function sanitizeString(str, maxLen = 200) {
    if (typeof str !== 'string') return '';
    return str
        .replace(/[<>]/g, '') // Elimina caracteres susceptibles de XSS
        .trim()
        .slice(0, maxLen);
}

// Bounding box UVM Campus Mérida
const CAMPUS_BOUNDS = {
    minLat: 21.0450,
    maxLat: 21.0500,
    minLng: -89.6350,
    maxLng: -89.6290
};

function validarCoordenadas(coords) {
    if (!coords || typeof coords !== 'object') {
        return {
            lat: 21.0475,
            lng: -89.6322
        };
    }
    let lat = parseFloat(coords.lat);
    let lng = parseFloat(coords.lng);

    if (isNaN(lat) || isNaN(lng) ||
        lat < CAMPUS_BOUNDS.minLat || lat > CAMPUS_BOUNDS.maxLat ||
        lng < CAMPUS_BOUNDS.minLng || lng > CAMPUS_BOUNDS.maxLng) {
        // Fallback al centro oficial del campus
        lat = 21.0475;
        lng = -89.6322;
    }

    return { lat, lng };
}

// Catálogos permitidos
const TIPOS_VALIDOS = ['Medica', 'Seguridad', 'Incendio'];
const SEVERIDADES_VALIDAS = ['ALTA', 'MEDIA', 'BAJA'];

// Ruta REST: Crear Reporte de Emergencia
app.post('/api/v1/incidentes', reportLimiter, (req, res) => {
    let {
        matricula,
        nombre_reportante,
        telefono,
        tipo_emergencia,
        severidad,
        zona_id,
        coordenadas,
        descripcion
    } = req.body;

    // Sanitización y valores por defecto para campos de identidad opcionales
    nombre_reportante = sanitizeString(nombre_reportante, 100);
    if (!nombre_reportante) {
        nombre_reportante = "Anónimo";
    }

    telefono = sanitizeString(telefono, 30);
    if (!telefono) {
        telefono = "No proporcionado";
    }

    matricula = sanitizeString(matricula, 30);
    tipo_emergencia = sanitizeString(tipo_emergencia, 50);
    severidad = sanitizeString(severidad, 20).toUpperCase();
    zona_id = sanitizeString(zona_id, 100);
    descripcion = sanitizeString(descripcion, 500);

    // Validación estricta de campos obligatorios (matrícula ya no es obligatoria)
    if (!tipo_emergencia || !zona_id) {
        return res.status(400).json({
            error: "Faltan campos obligatorios en el reporte (tipo_emergencia o zona_id)."
        });
    }

    if (!TIPOS_VALIDOS.includes(tipo_emergencia)) {
        return res.status(400).json({
            error: `Tipo de emergencia no válido. Valores permitidos: ${TIPOS_VALIDOS.join(', ')}.`
        });
    }

    if (!SEVERIDADES_VALIDAS.includes(severidad)) {
        severidad = "MEDIA";
    }

    const coordsValidadas = validarCoordenadas(coordenadas);

    // Simulación de respuesta SOAP interna del expediente médico por teléfono o Visitante / Comunidad UVM
    const expedienteSoap = buscarExpedienteMedico({
        telefono,
        matricula,
        nombre: nombre_reportante
    });

    const nuevoIncidente = {
        id: `INC-${Math.floor(1000 + Math.random() * 9000)}`,
        nombre_reportante,
        telefono,
        matricula: matricula || undefined,
        tipo_emergencia,
        severidad,
        zona_id,
        coordenadas: coordsValidadas,
        descripcion: descripcion || "Sin descripción proporcionada.",
        estado: "REPORTADO",
        timestamp: new Date().toISOString(),
        expediente_soap: expedienteSoap
    };

    incidentesActivos.unshift(nuevoIncidente);

    // Limitar historial en memoria a los últimos 50 incidentes
    if (incidentesActivos.length > 50) {
        incidentesActivos.pop();
    }

    // Emitir alerta en tiempo real al Centro de Mando Web vía WebSocket
    io.emit('nueva_alerta', nuevoIncidente);

    return res.status(201).json({
        mensaje: "Emergencia registrada y transmitida al Centro de Mando con éxito.",
        incidente: nuevoIncidente
    });
});

// Ruta REST: Obtener incidentes activos para el mapa
app.get('/api/v1/incidentes/activos', (req, res) => {
    res.json(incidentesActivos);
});

// Ruta especial para la Expo: Limpiar el tablero
app.post('/api/v1/expo/reset', (req, res) => {
    incidentesActivos = [];
    io.emit('limpiar_mapa', {});
    res.json({ mensaje: "Tablero reiniciado para la siguiente demostración." });
});

// Simulación de Endpoint SOAP (XML) para auditoría o sistemas legacy
app.post('/soap/ExpedienteMedicoService', (req, res) => {
    let telefono = '';
    let matricula = '';

    // Extracción de parámetros si se recibe JSON
    if (typeof req.body === 'object' && req.body !== null) {
        telefono = req.body.telefono || req.body.contacto || req.body.phone || '';
        matricula = req.body.matricula || '';
    } else if (typeof req.body === 'string') {
        // Extracción mediante expresiones regulares en caso de XML SOAP
        const telMatch = req.body.match(/<(?:med:)?(?:Telefono|Contacto|telefono|contacto)>(.*?)<\/(?:med:)?(?:Telefono|Contacto|telefono|contacto)>/i);
        if (telMatch && telMatch[1]) {
            telefono = telMatch[1].trim();
        }
        const matMatch = req.body.match(/<(?:med:)?(?:Matricula|matricula)>(.*?)<\/(?:med:)?(?:Matricula|matricula)>/i);
        if (matMatch && matMatch[1]) {
            matricula = matMatch[1].trim();
        }
    }

    // Parámetros por query string como fallback
    if (!telefono && req.query) {
        telefono = req.query.telefono || req.query.contacto || '';
        matricula = matricula || req.query.matricula || '';
    }

    telefono = sanitizeString(telefono, 30);
    matricula = sanitizeString(matricula, 30);

    const expediente = buscarExpedienteMedico({ telefono, matricula });

    const xmlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:med="http://aegiscampus.uvm.edu.mx/ws/medicos">
   <soapenv:Body>
      <med:ConsultarExpedienteResponse>
         <med:Titular>${expediente.titular || 'Visitante / Comunidad UVM'}</med:Titular>
         <med:Afiliacion>${expediente.afiliacion || 'Visitante / Comunidad UVM'}</med:Afiliacion>
         <med:EstatusPoliza>${expediente.estatus_poliza || 'ACTIVA'}</med:EstatusPoliza>
         <med:TipoSangre>${expediente.tipo_sangre}</med:TipoSangre>
         <med:AlergiasCriticas>${expediente.alergias}</med:AlergiasCriticas>
         <med:PolizaSeguro>${expediente.poliza}</med:PolizaSeguro>
         <med:ContactoEmergencia>${expediente.contacto}</med:ContactoEmergencia>
      </med:ConsultarExpedienteResponse>
   </soapenv:Body>
</soapenv:Envelope>`;
    
    res.setHeader('Content-Type', 'text/xml');
    res.send(xmlResponse);
});

// Gestión de conexiones de Socket.io
io.on('connection', (socket) => {
    console.log(`[Socket.io] Nuevo cliente conectado: ${socket.id}`);
    socket.on('disconnect', () => {
        console.log(`[Socket.io] Cliente desconectado: ${socket.id}`);
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`[Aegis Campus] Servidor activo en http://localhost:${PORT}`);
});